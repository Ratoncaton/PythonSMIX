
user_input = input("Introdueix un nombre:\n")

user_sum_of_numbers = 0


for i in user_input:
    user_sum_of_numbers += int(i)

print(user_sum_of_numbers)


#Made By Walid El Ourfi 1 SMX B 