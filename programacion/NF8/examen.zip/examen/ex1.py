import random

num_aleatori = random.randint(1, 100)

for i in range(1, 101):
    if i == num_aleatori:
        print("El nombre és: {}".format(i))



#Made By Walid El Ourfi 1 SMX B 