#Calculadora que ensenya el doble del nombre introduit
#11/01/23 
#By Walid El ourfi


entry = int(input("Esriu un número: "))

print("El doble del teu número és {}".format(entry * 2))