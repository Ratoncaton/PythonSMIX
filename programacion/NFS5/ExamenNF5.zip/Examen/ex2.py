#Mostra el nom introduit però en majuscules i quants caracters té
#11/01/23 
#By Walid El ourfi


entry = input("Introdueixi el vostre nom: ")


print("El nom {} conté {} caracters".format(entry.upper(), len(entry)))