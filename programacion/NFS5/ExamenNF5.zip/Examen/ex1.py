#Ensenya les unitats de miler del nombre que l'usuari posa.
#11/01/23 
#By Walid El ourfi


entry = input("Introdueix un número: ")

print("Les unitats de miler del nombre {} són {}".format(entry, entry[0:1]))